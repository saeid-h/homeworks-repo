
from redactor import unredactor


def test_function():
    glf = unredactor.train ()
    assert  1 == 1
