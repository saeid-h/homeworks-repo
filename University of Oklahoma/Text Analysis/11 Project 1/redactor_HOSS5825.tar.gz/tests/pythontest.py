# content of test_assert1.py
import pytest
def f():
    return 3

def test_function():
    assert f() == 3