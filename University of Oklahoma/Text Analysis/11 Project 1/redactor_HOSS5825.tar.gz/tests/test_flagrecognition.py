
from redactor import redactor


def test_function():
    options, args = redactor.flagRecognition ()
    assert  1 == 1
