
from extracredit import dataExtraction


def test_function():
    assert dataExtraction.download_book ('plautus')
